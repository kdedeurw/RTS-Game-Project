using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraControls : MonoBehaviour
{
    [SerializeField] private Camera _camera = null;
    [SerializeField] private float _moveSpeed = 15.0f;
    [SerializeField] private float _zoomSpeed = 1.0f;
    [SerializeField] private float _rotateSpeed = 10.0f;
    [SerializeField] private float _minHeight = 1.0f;
    [SerializeField] private float _maxHeight = 7.5f;

    private Vector2 _rotPos1 = new Vector2();
    private Vector2 _rotPos2 = new Vector2();

    private void Start()
    {
        //_camera = GetComponent<Camera>();
        if (!_camera)
        {
            _camera = GetComponentInChildren<Camera>();
            if (!_camera)
                Debug.LogError("Attached script did not find camera on gameobject!");
        }
    }

    void Update()
    {
        float horInput = Input.GetAxis("Horizontal");
        float verInput = Input.GetAxis("Vertical");
        float scrollWheel = Input.GetAxis("ScrollWheel");
        float middleMouse = Input.GetAxis("Mouse2");

        Vector3 movement = new Vector3();
        movement += horInput * _moveSpeed * Vector3.right;
        movement += verInput * _moveSpeed * Vector3.up;

        if (_camera)
        {
            _camera.orthographicSize += scrollWheel * _zoomSpeed * Time.deltaTime;
            _camera.orthographicSize = Mathf.Clamp(_camera.orthographicSize, _minHeight, _maxHeight);
        }

        //TODO: improve input calls
        if (Input.GetMouseButtonDown(2))
        {
            _rotPos1 = Input.mousePosition;
        }
        if (Input.GetMouseButton(2))
        {
            _rotPos2 = Input.mousePosition;

            float dx = (_rotPos1 - _rotPos2).x * _rotateSpeed * _camera.orthographicSize * Time.deltaTime;
            //float dy = (_rotPos1 - _rotPos2).y * _rotateSpeed;

            transform.rotation *= Quaternion.Euler(new Vector3(0, 0, dx));

            _rotPos1 = _rotPos2;
        }

        transform.position += movement * Time.deltaTime;
    }
}