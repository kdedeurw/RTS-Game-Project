using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RTSControls : MonoBehaviour
{
    private bool _hasLetGo = true;
    private Rect _selectionRect = Rect.zero;
    private List<BaseUnit> _selectedUnits = new List<BaseUnit>();
    [SerializeField] private bool unitManager = false;

    void Update()
    {
        //TODO: subtract half of resolution

        if (!_hasLetGo)
        {
            Vector2 mousePos = Input.mousePosition;
            _selectionRect.width = transform.position.x + _selectionRect.x - mousePos.x / Screen.currentResolution.width;
            _selectionRect.height = transform.position.y + _selectionRect.y - mousePos.y / Screen.currentResolution.height;
        }

        if (Input.GetMouseButtonDown(0))
        {
            Vector2 mousePos = Input.mousePosition;
            _selectionRect.x = transform.position.x + mousePos.x / Screen.currentResolution.width;
            _selectionRect.y = transform.position.y + mousePos.y / Screen.currentResolution.height;
            _hasLetGo = false;
        }
        else if (Input.GetMouseButtonUp(0))
        {
            _hasLetGo = true;
            //Vector2 mousePos = Input.mousePosition;
            //
            //_selectionRect.width = _selectionRect.x - mousePos.x / 100.0f;
            //_selectionRect.height = _selectionRect.y - mousePos.y / 100.0f;
            ////TODO: 
            ////Rect rect = Rect.zero;
            ////_selectionRect.Overlaps(rect);
        }
    }

    private void SelectUnitsInRect()
    {
        //TODO: select all units inside of rect
    }

    private void SelectAllUnits()
    {
        //TODO: select all units of correct team
    }

    public void DeselectUnit()
    {
        //TODO: deselect upon mousepos/rect
    }

    public void DeselectAllUnits()
    {
        _selectedUnits.Clear();
    }

    private void OnDrawGizmos()
    {
        if (_hasLetGo)
            return;

        Gizmos.color = Color.red;
        Gizmos.DrawLine(new Vector3(_selectionRect.x, _selectionRect.y, -1), new Vector3(_selectionRect.x + _selectionRect.width, _selectionRect.y, -1));
        Gizmos.DrawLine(new Vector3(_selectionRect.x, _selectionRect.y, -1), new Vector3(_selectionRect.x, _selectionRect.y + _selectionRect.height, -1));
        Gizmos.DrawLine(new Vector3(_selectionRect.x + _selectionRect.width, _selectionRect.y + _selectionRect.height, -1), new Vector3(_selectionRect.x + _selectionRect.width, _selectionRect.y, -1));
        Gizmos.DrawLine(new Vector3(_selectionRect.x + _selectionRect.width, _selectionRect.y + _selectionRect.height, -1), new Vector3(_selectionRect.x, _selectionRect.y + _selectionRect.height, -1));
    }
}