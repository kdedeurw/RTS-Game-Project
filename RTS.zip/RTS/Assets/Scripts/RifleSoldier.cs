using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RifleSoldier : BaseUnit
{
    [SerializeField] private Animator _legsAnimator = null;

    void Start()
    {

    }

    void Update()
    {
        
    }

    public override void Kill()
    {
        Destroy(gameObject);
    }

    public override void Damage(int amount)
    {
        if (_health <= 0)
            return;

        _health -= amount;
        if (_health <= 0)
            OnDeath();
    }

    protected override void OnDeath()
    {
        Kill();
    }
}