using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class BaseUnit : BaseEntity
{
    public enum UnitType:byte
    {
        Typeless = 0,
        Light = 1, //bonus speed
        Armoured = 2, //bonus armour
        Infantry = 4, //can get in buildings/humvees
        Vehicle = 8, //cannot get in buildings/humvees
        Elite = 16, //bonus health/abilities 
    }
    //TODO: make use of bitwise enum instead of 1 value

    //TODO: ALL UNIT STATS + TYPE
    [SerializeField] private UnitType _type;
    [SerializeField] protected int _health;
    [SerializeField] protected float _moveSpeed;
    [SerializeField] protected float _attackSpeed;

    public UnitType Type
    {
        get { return _type; }
    }

    protected virtual void Start()
    {
        if (_type == 0)
            Debug.LogWarning("Unit has no type! : " + gameObject.name);
    }

    public virtual void Kill()
    {
        Destroy(gameObject);
    }

    public virtual void Damage(int amount)
    {
        if (_health <= 0)
            return;

        _health -= amount;
        if (_health <= 0)
            OnDeath();
    }

    protected virtual void OnDeath()
    {
        Kill();
    }
}