using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BaseEntity : MonoBehaviour
{
    public enum Teams:byte
    {
        Neutral,
        Team0,
        Team1,
        Team2,
        Team3,
        Hostile,
    }

    [SerializeField] protected Teams _team;
    public Teams Team
    {
        get { return _team; }
        set { _team = value; }
    }

    void Start()
    {
        
    }


    void Update()
    {
        
    }
}