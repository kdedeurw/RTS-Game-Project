using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BaseController : MonoBehaviour
{
    [SerializeField] private float _speed = 10.0f;
    [SerializeField] private Rigidbody2D _rigidbody;
    [SerializeField] private Collider2D _collider;

    public Vector2 DesiredMovement
    { 
        get;
        set;
    }
    public Vector2 DesiredLookAt
    {
        get;
        set;
    }

    void Start()
    {
    }

    void Update()
    {
    }

    private void FixedUpdate()
    {
        Vector2 currPos = new Vector2();
        currPos.x = transform.position.x;
        currPos.y = transform.position.y;
        _rigidbody.MovePosition(currPos + DesiredMovement * Time.fixedDeltaTime * _speed);

        float angle = Mathf.Atan2(DesiredLookAt.y, DesiredLookAt.x) * Mathf.Rad2Deg;
        _rigidbody.MoveRotation(angle);
    }
}
